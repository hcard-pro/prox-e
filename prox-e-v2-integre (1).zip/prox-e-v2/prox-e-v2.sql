-- =====================================================================
-- Prox-e v2 : téléphone obligatoire, click & collect / livraison,
-- créneaux limités, modification réservée à la production,
-- paiement en ligne (Stripe).
--
-- À exécuter UNE FOIS dans Supabase > SQL Editor (ré-exécutable sans risque).
-- Ne modifie pas ta fonction place_order : la nouvelle place_order_v2
-- l'appelle, puis ajoute les nouvelles informations à la commande.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Nouvelles colonnes
-- ---------------------------------------------------------------------
alter table tenant_branding add column if not exists fulfillment jsonb;
alter table tenant_branding add column if not exists online_payment boolean not null default false;

alter table orders add column if not exists customer_email text;
alter table orders add column if not exists fulfillment_mode text not null default 'pickup';
alter table orders add column if not exists delivery_address jsonb;
alter table orders add column if not exists delivery_fee_cents integer not null default 0;
alter table orders add column if not exists amount_paid_cents integer not null default 0;
alter table orders add column if not exists paid_online boolean not null default false;
alter table orders add column if not exists stripe_session_id text;
alter table orders add column if not exists public_token uuid not null default gen_random_uuid();
alter table orders add column if not exists modified_at timestamptz;

alter table order_items add column if not exists line_total_cents integer;

-- Compte Stripe de chaque boutique (écrit uniquement par la fonction serveur)
create table if not exists tenant_payments (
  tenant_id uuid primary key references tenants(id) on delete cascade,
  stripe_account_id text,
  charges_enabled boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table tenant_payments enable row level security;
drop policy if exists tenant_payments_read on tenant_payments;
create policy tenant_payments_read on tenant_payments for select using (true);

-- Historique des modifications faites en production
create table if not exists order_modifications (
  id bigint generated always as identity primary key,
  order_id uuid not null references orders(id) on delete cascade,
  tenant_id uuid not null,
  modified_by text,
  changes jsonb not null,
  created_at timestamptz not null default now()
);
create index if not exists order_modifications_order_idx on order_modifications(order_id);
alter table order_modifications enable row level security;
drop policy if exists order_modifications_owner_read on order_modifications;
create policy order_modifications_owner_read on order_modifications for select
  using (tenant_id in (select tenant_id from profiles where id = auth.uid()));

create index if not exists orders_tenant_pickup_idx on orders(tenant_id, pickup_at);

-- ---------------------------------------------------------------------
-- 2. Outils
-- ---------------------------------------------------------------------

-- Téléphone : renvoie +33XXXXXXXXX (ou +international), sinon NULL
create or replace function proxe_phone(p text) returns text
language plpgsql immutable as $$
declare d text;
begin
  if p is null or p ~ '[^0-9+().\s-]' then return null; end if;
  d := regexp_replace(p, '[^0-9+]', '', 'g');
  if position('+' in d) > 1 then return null; end if;
  if d like '00%' then d := '+' || substr(d, 3); end if;
  if d like '+33%' then d := '0' || regexp_replace(substr(d, 4), '^0', ''); end if;
  if d ~ '^0[1-9][0-9]{8}$' then return '+33' || substr(d, 2); end if;
  if d ~ '^\+[1-9][0-9]{8,14}$' then return d; end if;
  return null;
end $$;

-- Distance en km entre deux points GPS
create or replace function proxe_km(lat1 float8, lng1 float8, lat2 float8, lng2 float8) returns float8
language sql immutable as $$
  select 2 * 6371 * asin(sqrt(
    power(sin(radians(lat2 - lat1) / 2), 2) +
    cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lng2 - lng1) / 2), 2)));
$$;

-- Le créneau est-il dans les horaires de la boutique ?
create or replace function proxe_slot_ok(f jsonb, p_mode text, p_at timestamptz) returns boolean
language plpgsql stable as $$
declare
  loc timestamp := p_at at time zone 'Europe/Paris';
  dur int := coalesce((f->>'slot_min')::int, 30);
  k text := (array['sun','mon','tue','wed','thu','fri','sat'])[extract(dow from loc)::int + 1];
  hrs jsonb := case when p_mode = 'delivery' and jsonb_typeof(f->'dhours') = 'object' then f->'dhours' else f->'hours' end;
  r jsonb;
begin
  if coalesce(f->'closed', '[]'::jsonb) ? to_char(loc, 'YYYY-MM-DD') then return false; end if;
  for r in select * from jsonb_array_elements(coalesce(hrs->k, '[]'::jsonb)) loop
    -- 00:00 en heure de fin = minuit
    if loc::time >= (r->>0)::time
       and loc::time::interval + make_interval(mins => dur)
           <= (case when (r->>1)::time = '00:00' then interval '24 hours' else (r->>1)::time::interval end) then
      return true;
    end if;
  end loop;
  return false;
end $$;

-- Frais de livraison : renvoie les centimes, ou une erreur lisible
create or replace function proxe_delivery_fee(f jsonb, p_address jsonb, p_subtotal int) returns int
language plpgsql stable as $$
declare
  z jsonb := f->'zone';
  fee int;
  km float8;
  r jsonb;
begin
  if p_address is null then raise exception 'ADRESSE_MANQUANTE'; end if;
  if p_subtotal < coalesce((f->>'min_order')::int, 0) then raise exception 'MINIMUM_LIVRAISON'; end if;
  if z->>'type' = 'radius' then
    if p_address->>'lat' is null or z->'origin'->>'lat' is null then raise exception 'ADRESSE_INTROUVABLE'; end if;
    km := proxe_km((z->'origin'->>'lat')::float8, (z->'origin'->>'lng')::float8,
                   (p_address->>'lat')::float8, (p_address->>'lng')::float8);
    select (t->>'fee')::int into fee
      from jsonb_array_elements(coalesce(z->'tiers', '[]'::jsonb)) t
     where km <= (t->>'km')::float8
     order by (t->>'km')::float8 limit 1;
  else
    select (p->>'fee')::int into fee
      from jsonb_array_elements(coalesce(z->'postcodes', '[]'::jsonb)) p
     where p->>'code' = trim(p_address->>'postcode') limit 1;
  end if;
  if fee is null then raise exception 'HORS_ZONE'; end if;
  if (f->>'free_above') is not null and p_subtotal >= (f->>'free_above')::int then return 0; end if;
  return greatest(fee, 0);
end $$;

-- Montant d'une ligne, avec le prix du lot si le produit en a un (ex. 5 donuts pour 5 €)
create or replace function proxe_line_total(p_product uuid, p_unit int, p_qty int) returns int
language sql stable as $$
  select coalesce(
    (select case when p.bundle_qty >= 2 and p.bundle_price_cents > 0
                 then (p_qty / p.bundle_qty) * p.bundle_price_cents + (p_qty % p.bundle_qty) * p_unit end
       from products p where p.id = p_product),
    p_unit * p_qty);
$$;

-- Type d'un paramètre de place_order (json ou jsonb, text…), pour l'appeler sans la connaître
create or replace function proxe_argtype(p_fn text, p_arg text) returns text
language sql stable as $$
  select format_type(coalesce(p.proallargtypes[i], (p.proargtypes::oid[])[i - 1]), null)
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace,
         generate_subscripts(p.proargnames, 1) i
   where n.nspname = 'public' and p.proname = p_fn and p.proargnames[i] = p_arg
   limit 1;
$$;

-- ---------------------------------------------------------------------
-- 3. Créneaux déjà pris (compteurs seulement, aucune donnée client)
-- ---------------------------------------------------------------------
create or replace function slot_counts(p_slug text, p_from timestamptz, p_to timestamptz)
returns table(at timestamptz, nb int)
language sql stable security definer set search_path = public as $$
  select o.pickup_at, count(*)::int
    from orders o join tenants t on t.id = o.tenant_id
   where t.slug = p_slug and o.pickup_at >= p_from and o.pickup_at < p_to
     and coalesce(o.status, '') <> 'canceled'
   group by o.pickup_at;
$$;
grant execute on function slot_counts(text, timestamptz, timestamptz) to anon, authenticated;

-- ---------------------------------------------------------------------
-- 4. Passer une commande (v2)
-- ---------------------------------------------------------------------
create or replace function place_order_v2(
  p_slug text, p_name text, p_phone text, p_pickup timestamptz,
  p_items jsonb, p_cakes jsonb, p_note text,
  p_email text default null, p_mode text default 'pickup', p_address jsonb default null,
  p_lead_min int default 0
) returns table(out_number int, out_total int, out_id uuid, out_token uuid, out_fee int)
language plpgsql security definer set search_path = public as $$
declare
  v_tenant uuid;
  f jsonb;
  v_phone text := proxe_phone(p_phone);
  v_email text := nullif(lower(trim(coalesce(p_email, ''))), '');
  v_mode text := coalesce(nullif(p_mode, ''), 'pickup');
  v_number int;
  v_total int;
  v_fee int := 0;
  v_max int;
  v_count int;
  v_lead int;
  v_id uuid;
  v_token uuid;
begin
  if v_phone is null then raise exception 'TELEPHONE_INVALIDE'; end if;
  if v_email is not null and v_email !~ '^[^\s@]+@[^\s@]+\.[^\s@]{2,}$' then raise exception 'EMAIL_INVALIDE'; end if;
  if v_mode not in ('pickup', 'delivery') then raise exception 'MODE_INVALIDE'; end if;

  select t.id, b.fulfillment into v_tenant, f
    from tenants t left join tenant_branding b on b.tenant_id = t.id
   where t.slug = p_slug;
  if v_tenant is null then raise exception 'BOUTIQUE_INTROUVABLE'; end if;

  -- Règles de la boutique (seulement si elle a activé les créneaux)
  if f is not null and coalesce((f->>'on')::boolean, false) then
    if v_mode = 'pickup' and not coalesce((f->>'pickup')::boolean, true) then raise exception 'MODE_INVALIDE'; end if;
    if v_mode = 'delivery' and not coalesce((f->>'delivery')::boolean, false) then raise exception 'MODE_INVALIDE'; end if;

    v_lead := greatest(coalesce((f->>'lead_min')::int, 0), coalesce(p_lead_min, 0));
    if p_pickup < now() + make_interval(mins => v_lead) - interval '5 minutes' then raise exception 'CRENEAU_PASSE'; end if;
    if not proxe_slot_ok(f, v_mode, p_pickup) then raise exception 'CRENEAU_FERME'; end if;

    v_max := coalesce((f->>'max_per_slot')::int, 0);
    if v_max > 0 then
      perform pg_advisory_xact_lock(hashtext(v_tenant::text || p_pickup::text));
      select count(*) into v_count from orders
       where tenant_id = v_tenant and pickup_at = p_pickup and coalesce(status, '') <> 'canceled';
      if v_count >= v_max then raise exception 'CRENEAU_COMPLET'; end if;
    end if;
  elsif v_mode = 'delivery' then
    raise exception 'MODE_INVALIDE';
  end if;

  -- Commande créée par ta fonction habituelle (prix recalculés en base)
  execute format(
    'select out_number, out_total from public.place_order(p_slug => $1::%s, p_name => $2::%s, p_phone => $3::%s, p_pickup => $4::%s, p_items => $5::%s, p_cakes => $6::%s, p_note => $7::%s)',
    proxe_argtype('place_order', 'p_slug'), proxe_argtype('place_order', 'p_name'),
    proxe_argtype('place_order', 'p_phone'), proxe_argtype('place_order', 'p_pickup'),
    proxe_argtype('place_order', 'p_items'), proxe_argtype('place_order', 'p_cakes'),
    proxe_argtype('place_order', 'p_note'))
  into v_number, v_total
  using p_slug, p_name, v_phone, p_pickup, p_items, p_cakes, p_note;

  if v_mode = 'delivery' then
    v_fee := proxe_delivery_fee(f, p_address, v_total);
  end if;

  update orders set
      customer_phone = v_phone,
      customer_email = coalesce(v_email, customer_email),
      fulfillment_mode = v_mode,
      delivery_address = case when v_mode = 'delivery' then p_address end,
      delivery_fee_cents = v_fee,
      total_cents = v_total + v_fee
    where tenant_id = v_tenant and number = v_number
    returning id, public_token into v_id, v_token;

  return query select v_number, v_total + v_fee, v_id, v_token, v_fee;
end $$;
grant execute on function place_order_v2(text, text, text, timestamptz, jsonb, jsonb, text, text, text, jsonb, int) to anon, authenticated;

-- ---------------------------------------------------------------------
-- 5. Modifier une commande : réservé à l'espace équipe de la boutique
-- ---------------------------------------------------------------------
-- p_items : [{ "id": "<id ligne>", "qty": 3 }]   (qty 0 = retiré)
-- p_cakes : [{ "id": "<id gâteau>", "inscription": "...", "note": "..." }]
create or replace function production_update_order(
  p_order_id uuid, p_items jsonb default null, p_cakes jsonb default null,
  p_pickup timestamptz default null, p_note text default null, p_by text default null
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  o orders%rowtype;
  it record;
  c jsonb;
  v_old_items int;
  v_new_items int;
  v_new_total int;
  v_changes jsonb := '{}'::jsonb;
  v_warning text;
  v_lines int;
  v_q int;
  v_line int;
begin
  select * into o from orders where id = p_order_id for update;
  if not found then raise exception 'COMMANDE_INTROUVABLE'; end if;
  if not exists (select 1 from profiles where id = auth.uid()
                 and ((role = 'shop' and tenant_id = o.tenant_id) or role = 'admin')) then
    raise exception 'permission denied';
  end if;

  -- Articles du catalogue
  if p_items is not null and jsonb_typeof(p_items) = 'array' then
    select coalesce(sum(coalesce(line_total_cents, proxe_line_total(product_id, unit_price_cents, qty))), 0) into v_old_items
      from order_items where order_id = o.id;

    for it in
      select oi.id, oi.name, oi.qty as old_qty, oi.unit_price_cents, oi.product_id,
             greatest(0, least(999, (x->>'qty')::int)) as new_qty
        from jsonb_array_elements(p_items) x
        join order_items oi on oi.id::text = x->>'id' and oi.order_id = o.id
    loop
      continue when it.new_qty = it.old_qty;
      if it.new_qty = 0 then
        delete from order_items where id = it.id;
      else
        v_line := proxe_line_total(it.product_id, it.unit_price_cents, it.new_qty);
        update order_items set qty = it.new_qty where id = it.id;
        begin
          update order_items set line_total_cents = v_line where id = it.id;
        exception when others then null; -- colonne calculée automatiquement : rien à faire
        end;
      end if;
      v_changes := v_changes || jsonb_build_object(it.name, jsonb_build_object('avant', it.old_qty, 'apres', it.new_qty));
    end loop;

    select count(*) into v_lines from order_items where order_id = o.id;
    if v_lines = 0 and not exists (select 1 from order_cakes where order_id = o.id) then
      raise exception 'COMMANDE_VIDE';
    end if;

    select coalesce(sum(coalesce(line_total_cents, proxe_line_total(product_id, unit_price_cents, qty))), 0) into v_new_items
      from order_items where order_id = o.id;
    v_new_total := o.total_cents + (v_new_items - v_old_items);
  else
    v_new_total := o.total_cents;
  end if;

  -- Gâteaux sur-mesure : inscription et remarque
  if p_cakes is not null and jsonb_typeof(p_cakes) = 'array' then
    for c in select * from jsonb_array_elements(p_cakes) loop
      update order_cakes set
          inscription = coalesce(left(c->>'inscription', 80), inscription),
          note = coalesce(left(c->>'note', 300), note)
        where id::text = c->>'id' and order_id = o.id
          and (inscription is distinct from coalesce(left(c->>'inscription', 80), inscription)
               or note is distinct from coalesce(left(c->>'note', 300), note));
      if found then v_changes := v_changes || jsonb_build_object('gâteau', 'modifié'); end if;
    end loop;
  end if;

  if p_pickup is not null and p_pickup is distinct from o.pickup_at then
    v_changes := v_changes || jsonb_build_object('retrait', jsonb_build_object('avant', o.pickup_at, 'apres', p_pickup));
  end if;
  if p_note is not null and p_note is distinct from coalesce(o.note, '') then
    v_changes := v_changes || jsonb_build_object('remarque', 'modifiée');
  end if;
  if v_new_total <> o.total_cents then
    v_changes := v_changes || jsonb_build_object('total', jsonb_build_object('avant', o.total_cents, 'apres', v_new_total));
  end if;

  if v_changes = '{}'::jsonb then
    return jsonb_build_object('changed', false, 'total', o.total_cents);
  end if;

  update orders set
      pickup_at = coalesce(p_pickup, pickup_at),
      note = case when p_note is null then note else nullif(left(p_note, 1000), '') end,
      total_cents = v_new_total,
      paid = case when o.amount_paid_cents > 0 and v_new_total > o.amount_paid_cents then false else paid end,
      modified_at = now()
    where id = o.id;

  if o.amount_paid_cents > 0 and v_new_total > o.amount_paid_cents then
    v_warning := 'COMPLEMENT:' || (v_new_total - o.amount_paid_cents);
  elsif o.amount_paid_cents > v_new_total then
    v_warning := 'TROP_PERCU:' || (o.amount_paid_cents - v_new_total);
  end if;

  insert into order_modifications(order_id, tenant_id, modified_by, changes)
  values (o.id, o.tenant_id, left(coalesce(p_by, 'Production'), 60), v_changes);

  return jsonb_build_object('changed', true, 'total', v_new_total, 'warning', v_warning, 'changes', v_changes);
end $$;
revoke execute on function production_update_order(uuid, jsonb, jsonb, timestamptz, text, text) from public, anon;
grant execute on function production_update_order(uuid, jsonb, jsonb, timestamptz, text, text) to authenticated;

-- Les clients ne passent plus que par place_order_v2 : ils n'ont aucun droit
-- d'écriture directe sur les commandes.
revoke insert, update, delete on orders, order_items, order_cakes from anon;
