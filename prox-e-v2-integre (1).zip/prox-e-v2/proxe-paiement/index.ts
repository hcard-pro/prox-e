// =====================================================================
// Prox-e — fonction Supabase « proxe-paiement »
// Paiement en ligne Stripe (l'argent va sur le compte de chaque boutique),
// e-mail « paiement confirmé » et e-mail « commande modifiée ».
//
// Supabase > Edge Functions > Deploy a new function > nom : proxe-paiement
// Coller ce fichier, puis DÉSACTIVER « Verify JWT » (Stripe doit pouvoir l'appeler).
// Secrets (Edge Functions > Secrets) : STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET,
//   RESEND_API_KEY, RESEND_FROM   (ex. "Prox-e <commandes@proxe-commande.fr>")
//   facultatif : PLATFORM_FEE_CENTS (ta commission par paiement, en centimes)
// =====================================================================
import Stripe from 'npm:stripe@17';
import { createClient } from 'npm:@supabase/supabase-js@2';

const env = (k: string) => Deno.env.get(k) ?? '';
const stripe = new Stripe(env('STRIPE_SECRET_KEY'), { httpClient: Stripe.createFetchHttpClient() });
const db = createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });
class HttpError extends Error { constructor(public status: number, msg: string) { super(msg); } }

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json(405, { error: 'Méthode non autorisée' });
  try {
    const sig = req.headers.get('stripe-signature');
    if (sig) return await webhook(await req.text(), sig);

    const body = await req.json().catch(() => ({}));
    switch (body.action) {
      case 'checkout': return json(200, await checkout(body));
      case 'connect': return json(200, await connect(req, body));
      case 'status': return json(200, await status(req));
      case 'notify': return json(200, await notify(req, body));
      default: throw new HttpError(400, 'Action inconnue.');
    }
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 500;
    if (status >= 500) console.error(e);
    return json(status, { error: status >= 500 ? 'Erreur serveur, réessayez.' : (e as Error).message });
  }
});

// ---------------------------------------------------------------------
// Données
// ---------------------------------------------------------------------
async function loadOrder(id: string) {
  const { data, error } = await db.from('orders').select('*, order_items(*), order_cakes(*)').eq('id', id).maybeSingle();
  if (error) throw error;
  if (!data) throw new HttpError(404, 'Commande introuvable.');
  return data;
}
async function loadShop(tenantId: string) {
  const [t, b, p] = await Promise.all([
    db.from('tenants').select('id,name,slug,status').eq('id', tenantId).single(),
    db.from('tenant_branding').select('*').eq('tenant_id', tenantId).maybeSingle(),
    db.from('tenant_payments').select('*').eq('tenant_id', tenantId).maybeSingle(),
  ]);
  if (t.error) throw t.error;
  return { ...t.data, branding: b.data ?? {}, pay: p.data ?? {} };
}
/** Compte de la boutique connecté à cet appareil (espace équipe) */
async function owner(req: Request) {
  const token = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '');
  if (!token) throw new HttpError(401, 'Connexion de la boutique requise.');
  const { data, error } = await db.auth.getUser(token);
  if (error || !data.user) throw new HttpError(401, 'Connexion de la boutique requise.');
  const { data: p } = await db.from('profiles').select('role,tenant_id').eq('id', data.user.id).maybeSingle();
  if (!p || p.role !== 'shop' || !p.tenant_id) throw new HttpError(403, 'Action non autorisée pour ce compte.');
  return p.tenant_id as string;
}
const backUrl = (u: unknown) => {
  try {
    const x = new URL(String(u));
    if (x.protocol !== 'https:' && x.hostname !== 'localhost') throw 0;
    return x.origin + x.pathname;
  } catch { throw new HttpError(400, 'Adresse de retour invalide.'); }
};

// ---------------------------------------------------------------------
// 1. Paiement d'une commande (appelé par la borne / le téléphone du client)
// ---------------------------------------------------------------------
async function checkout({ order_id, token, return_url }: Record<string, string>) {
  if (!order_id || !token) throw new HttpError(400, 'Commande manquante.');
  const o = await loadOrder(order_id);
  if (String(o.public_token) !== String(token)) throw new HttpError(403, 'Lien de paiement invalide.');
  if (o.status === 'canceled') throw new HttpError(409, 'Cette commande est annulée.');
  const shop = await loadShop(o.tenant_id);
  if (!shop.branding.online_payment || !shop.pay.stripe_account_id || !shop.pay.charges_enabled) {
    throw new HttpError(400, "Le paiement en ligne n'est pas activé pour cette boutique.");
  }
  const toPay = (o.total_cents ?? 0) - (o.amount_paid_cents ?? 0);
  if (toPay <= 0) throw new HttpError(409, 'Cette commande est déjà réglée.');
  if (toPay < 50) throw new HttpError(400, 'Montant trop faible pour un paiement en ligne (minimum 0,50 €).');

  // Détail des lignes ; si le détail ne tombe pas juste (complément, remise…), une seule ligne.
  const lines: { name: string; amount: number }[] = [
    ...(o.order_items ?? []).map((i: any) => ({
      name: `${i.qty} × ${i.name}`,
      amount: i.line_total_cents ?? i.unit_price_cents * i.qty,
    })),
    ...(o.order_cakes ?? []).map((c: any) => ({
      name: `Gâteau sur-mesure${c.size_label ? ' – ' + c.size_label : ''}`,
      amount: c.price_cents ?? 0,
    })),
    ...(o.delivery_fee_cents > 0 ? [{ name: 'Livraison', amount: o.delivery_fee_cents }] : []),
  ].filter((l) => l.amount > 0);
  const sum = lines.reduce((s, l) => s + l.amount, 0);
  const items = (sum === toPay ? lines : [{
    name: (o.amount_paid_cents > 0 ? 'Complément – ' : '') + `Commande n° ${o.number}`, amount: toPay,
  }]).map((l) => ({
    quantity: 1,
    price_data: { currency: 'eur', unit_amount: l.amount, product_data: { name: l.name.slice(0, 250) } },
  }));

  const base = backUrl(return_url);
  const fee = Math.max(0, Math.round(Number(env('PLATFORM_FEE_CENTS')) || 0));
  const email = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(o.customer_email ?? '') ? o.customer_email : undefined;

  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    locale: 'fr',
    line_items: items,
    customer_email: email,
    client_reference_id: o.id,
    metadata: { order_id: o.id, tenant_id: o.tenant_id },
    payment_intent_data: {
      description: `${shop.name} – commande n° ${o.number}`,
      metadata: { order_id: o.id, tenant_id: o.tenant_id },
      ...(fee > 0 && fee < toPay ? { application_fee_amount: fee } : {}),
    },
    expires_at: Math.floor(Date.now() / 1000) + 30 * 60,
    success_url: `${base}?paiement=ok&n=${o.number}#/b/${shop.slug}`,
    cancel_url: `${base}?paiement=annule&o=${o.id}&t=${o.public_token}#/b/${shop.slug}`,
  }, { stripeAccount: shop.pay.stripe_account_id });

  await db.from('orders').update({ stripe_session_id: session.id }).eq('id', o.id);
  return { url: session.url };
}

// ---------------------------------------------------------------------
// 2. Relier le compte Stripe de la boutique (espace gérant)
// ---------------------------------------------------------------------
async function connect(req: Request, { return_url }: Record<string, string>) {
  const tenantId = await owner(req);
  const shop = await loadShop(tenantId);
  let acct = shop.pay.stripe_account_id as string | undefined;
  if (!acct) {
    const a = await stripe.accounts.create({
      type: 'standard',
      country: 'FR',
      email: shop.branding.legal_email || undefined,
      business_profile: { name: shop.name },
      metadata: { tenant_id: tenantId },
    });
    acct = a.id;
    const { error } = await db.from('tenant_payments').upsert({ tenant_id: tenantId, stripe_account_id: acct, charges_enabled: false, updated_at: new Date().toISOString() });
    if (error) throw error;
  }
  const base = backUrl(return_url);
  const link = await stripe.accountLinks.create({
    account: acct,
    type: 'account_onboarding',
    refresh_url: `${base}?stripe=refresh#/b/${shop.slug}/gestion`,
    return_url: `${base}?stripe=retour#/b/${shop.slug}/gestion`,
  });
  return { url: link.url };
}

async function status(req: Request) {
  const tenantId = await owner(req);
  const { data } = await db.from('tenant_payments').select('*').eq('tenant_id', tenantId).maybeSingle();
  if (!data?.stripe_account_id) return { connected: false, charges_enabled: false };
  const a = await stripe.accounts.retrieve(data.stripe_account_id);
  await db.from('tenant_payments').update({ charges_enabled: !!a.charges_enabled, updated_at: new Date().toISOString() }).eq('tenant_id', tenantId);
  return { connected: true, charges_enabled: !!a.charges_enabled };
}

// ---------------------------------------------------------------------
// 3. E-mail « commande modifiée » (après une modification en production)
// ---------------------------------------------------------------------
async function notify(req: Request, { order_id }: Record<string, string>) {
  const tenantId = await owner(req);
  const o = await loadOrder(order_id);
  if (o.tenant_id !== tenantId) throw new HttpError(403, 'Action non autorisée pour ce compte.');
  if (!o.customer_email) return { sent: false };
  const shop = await loadShop(tenantId);
  const due = (o.total_cents ?? 0) - (o.amount_paid_cents ?? 0);
  const intro = 'La boutique a modifié votre commande. Voici le récapitulatif à jour.' +
    (o.amount_paid_cents > 0 && due > 0 ? ` Reste à régler au retrait : <strong>${eur(due)}</strong>.` : '') +
    ' Une question ? Répondez simplement à cet e-mail.';
  return { sent: await sendMail(shop, o, `Votre commande n° ${o.number} a été mise à jour – ${shop.name}`, 'Votre commande a été mise à jour', intro) };
}

// ---------------------------------------------------------------------
// 4. Webhook Stripe
// ---------------------------------------------------------------------
async function webhook(raw: string, sig: string) {
  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(raw, sig, env('STRIPE_WEBHOOK_SECRET'), undefined, Stripe.createSubtleCryptoProvider());
  } catch (e) {
    console.error('Signature Stripe invalide', (e as Error).message);
    return new Response('Signature invalide', { status: 400 });
  }
  const obj: any = event.data.object;

  if ((event.type === 'checkout.session.completed' || event.type === 'checkout.session.async_payment_succeeded') && obj.payment_status === 'paid') {
    const orderId = obj.metadata?.order_id;
    if (orderId) {
      const o = await loadOrder(orderId);
      const shop = await loadShop(o.tenant_id);
      if (event.account && event.account !== shop.pay.stripe_account_id) {
        console.error('Compte Stripe inattendu pour la commande', orderId);
      } else {
        // Ne compte le paiement qu'une fois, même si Stripe renvoie l'événement.
        const { data: done } = await db.from('orders')
          .update({ stripe_session_id: obj.id + ':ok', amount_paid_cents: (o.amount_paid_cents ?? 0) + obj.amount_total, paid: true, paid_online: true })
          .eq('id', orderId).eq('stripe_session_id', obj.id).select('id');
        if (done?.length) {
          const fresh = await loadOrder(orderId);
          if (!fresh.customer_email && obj.customer_details?.email) {
            fresh.customer_email = obj.customer_details.email;
            await db.from('orders').update({ customer_email: fresh.customer_email }).eq('id', orderId);
          }
          await sendMail(shop, fresh, `Paiement confirmé – commande n° ${fresh.number} – ${shop.name}`, 'Paiement confirmé, merci !',
            `Nous avons bien reçu votre paiement de <strong>${eur(obj.amount_total)}</strong>. Voici le récapitulatif de votre commande.`);
        }
      }
    }
  } else if (event.type === 'account.updated') {
    await db.from('tenant_payments').update({ charges_enabled: !!obj.charges_enabled, updated_at: new Date().toISOString() }).eq('stripe_account_id', obj.id);
  }
  return new Response('ok', { status: 200 });
}

// ---------------------------------------------------------------------
// E-mails (Resend)
// ---------------------------------------------------------------------
const eur = (c: number) => (c / 100).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' });
const esc = (s: unknown) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
const when = (iso: string) => new Date(iso).toLocaleString('fr-FR', { timeZone: 'Europe/Paris', weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });

async function sendMail(shop: any, o: any, subject: string, title: string, intro: string) {
  if (!o.customer_email || !env('RESEND_API_KEY')) return false;
  const row = (l: string, r: string, sub = '') => `<tr><td style="padding:8px 0;border-bottom:1px solid #eee">${l}${sub ? `<div style="color:#777;font-size:13px">${sub}</div>` : ''}</td><td style="padding:8px 0;border-bottom:1px solid #eee;text-align:right;white-space:nowrap">${r}</td></tr>`;
  const rows = [
    ...(o.order_items ?? []).map((i: any) => row(`${esc(i.qty)} × ${esc(i.name)}`, eur(i.line_total_cents ?? i.unit_price_cents * i.qty))),
    ...(o.order_cakes ?? []).map((c: any) => row(`Gâteau sur-mesure${c.size_label ? ', ' + esc(c.size_label) : ''}`, eur(c.price_cents ?? 0),
      [c.flavor && esc(c.flavor), c.inscription && `« ${esc(c.inscription)} »`].filter(Boolean).join(' · '))),
    ...(o.delivery_fee_cents > 0 ? [row('Livraison', eur(o.delivery_fee_cents))] : []),
  ].join('');
  const mode = o.fulfillment_mode === 'delivery'
    ? `Livraison : ${esc(o.delivery_address?.label ?? '')}`
    : `Retrait en boutique${shop.branding.legal_address ? ' : ' + esc(shop.branding.legal_address) : ''}`;
  const due = (o.total_cents ?? 0) - (o.amount_paid_cents ?? 0);
  const pay = due <= 0 ? 'Réglée en ligne' : o.amount_paid_cents > 0 ? `Reste à régler : ${eur(due)}` : 'À régler au retrait';
  const html = `<!doctype html><html lang="fr"><body style="margin:0;background:#f5f1ea;font-family:Arial,Helvetica,sans-serif;color:#2b1d14">
  <div style="max-width:560px;margin:0 auto;padding:24px"><div style="background:#fff;border-radius:12px;padding:24px">
  <p style="margin:0 0 4px;color:#9a6b3f;font-size:13px;text-transform:uppercase;letter-spacing:.05em">${esc(shop.name)}</p>
  <h1 style="margin:0 0 12px;font-size:22px">${esc(title)}</h1><p style="margin:0 0 16px">${intro}</p>
  <p style="margin:0 0 16px;font-size:18px">Commande n° <strong>${esc(o.number)}</strong></p>
  <table style="width:100%;border-collapse:collapse;font-size:15px">${rows}
  <tr><td style="padding:10px 0;font-weight:bold">Total</td><td style="text-align:right;font-weight:bold">${eur(o.total_cents ?? 0)}</td></tr></table>
  <p style="margin:16px 0 4px"><strong>${mode}</strong></p>
  <p style="margin:0 0 4px">${o.fulfillment_mode === 'delivery' ? 'Livraison' : 'Retrait'} : ${esc(when(o.pickup_at))}</p>
  <p style="margin:0">Paiement : ${pay}</p></div>
  <p style="font-size:12px;color:#8a7a6a;text-align:center;margin-top:16px">${esc(shop.name)} · commande passée avec Prox-e</p></div></body></html>`;
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env('RESEND_API_KEY')}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from: env('RESEND_FROM'), to: [o.customer_email], subject, html,
      ...(shop.branding.legal_email ? { reply_to: shop.branding.legal_email } : {}),
    }),
  });
  if (!res.ok) console.error('Resend', res.status, await res.text());
  return res.ok;
}
