# Prox-e v2 : installation

Trois fichiers : `index.html` (l'appli mise à jour), `prox-e-v2.sql` (la base), `proxe-paiement/index.ts` (le paiement en ligne).

## Étape 1 : la base (obligatoire, 2 minutes)
Supabase → **SQL Editor** → colle tout `prox-e-v2.sql` → **Run**.
Ta fonction `place_order` n'est pas modifiée : la nouvelle `place_order_v2` l'appelle puis ajoute téléphone vérifié, e-mail, mode, adresse et frais.

## Étape 2 : l'appli
Remplace `index.html` sur GitHub comme d'habitude. Netlify se met à jour tout seul.

Tant que tu n'actives rien dans **Vente en ligne**, la borne fonctionne comme avant (choix libre du jour et de l'heure), avec le téléphone désormais obligatoire et vérifié.

## Étape 3 : régler la boutique
Espace gérant → **Vente en ligne** :
- coche « Activer les créneaux… », puis Click & collect et/ou Livraison ;
- créneaux : durée, délai de préparation, nombre maximum de commandes par créneau, horaires, jours de fermeture ;
- livraison : codes postaux avec leurs frais, ou distance autour de la boutique (km → frais), minimum de commande, livraison offerte ;
- « Dès que possible » pour une friterie ou un snack.

## Étape 4 : le paiement en ligne (quand tu veux)
1. Crée ton compte sur **stripe.com** et active **Connect** (Paramètres → Connect).
2. Supabase → **Edge Functions** → **Deploy a new function** → nom **`proxe-paiement`** → colle `proxe-paiement/index.ts` → **désactive « Verify JWT »** → Deploy.
3. Supabase → Edge Functions → **Secrets** :
   - `STRIPE_SECRET_KEY` : `sk_test_…` pour tester, puis `sk_live_…`
   - `RESEND_API_KEY` : ta clé Resend
   - `RESEND_FROM` : `Prox-e <commandes@proxe-commande.fr>`
4. Stripe → Développeurs → **Webhooks** → Ajouter un endpoint :
   - URL : `https://czbawdiagxttaecqyiiz.supabase.co/functions/v1/proxe-paiement`
   - coche **« Événements sur les comptes connectés »**
   - événements : `checkout.session.completed`, `checkout.session.async_payment_succeeded`, `account.updated`
   - copie le secret `whsec_…` dans le secret Supabase `STRIPE_WEBHOOK_SECRET`.
5. Dans l'appli : Vente en ligne → **Relier un compte Stripe** (le commerçant crée son compte, l'argent arrive chez lui) → coche **Proposer « Payer maintenant »**.

Test : clés `sk_test`, carte `4242 4242 4242 4242`, date future, n'importe quel code.

## Ce qui change au quotidien
- **Client** : téléphone obligatoire ; choix retrait/livraison ; créneau libre ; adresse vérifiée ; « Payer maintenant » ou « Payer au retrait ». Après paiement : e-mail « Paiement confirmé » avec le récap.
- **Production** : bouton **Modifier la commande** (quantités, inscription et remarque des gâteaux, date/heure, remarques). Le total est recalculé, chaque modification est historisée, le client peut être prévenu par e-mail. Si une commande payée en ligne augmente, elle repasse « à payer » avec le reste à encaisser.
- Le client ne peut plus modifier une commande : seul l'espace équipe le peut.

## Bon à savoir
- Le domaine **proxe-commande.fr** doit être vérifié dans Resend, sinon les e-mails partent en indésirables.
- Remboursements : depuis le tableau de bord Stripe de la boutique (l'appli signale un trop-perçu).
- La vérification d'adresse utilise le service gratuit de l'IGN (France uniquement).
